' Ouvre le panneau Optizien (aucune fenetre noire).
Set fso = CreateObject("Scripting.FileSystemObject")
racine = fso.GetParentFolderName(WScript.ScriptFullName)
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = racine & "\systeme\app"
sh.Run """" & racine & "\systeme\python\pythonw.exe"" -m panneau", 0, False
